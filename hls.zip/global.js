var supportedVersions = ["0.12.4", "0.10.1", "0.9.1", "0.8.9","0.8.8","0.8.7","0.8.6","0.8.5","0.7.10", "0.6.21", "0.5.52"]
var currentVersion = supportedVersions[0]